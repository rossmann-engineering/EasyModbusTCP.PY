EasyModbusTCP - THE standard library for Modbus RTU and Modbus TCP

Python 2.7
Python 3.6

Requirements: pyserial (only for Modbus RTU)

See the following codesamples:

Example 1.1: Data exchange to a Siemens S7 PLC - Simple Example which Read and Writes some Values to the PLC and Print it at the console

Visit www.EayModbusTCP.net for more informations and Codesamples